my_chessmate
============

This is a simple chess game written in Java. 

Double click on the jar file to run the program. A Java installation is requied. 

The user can play against the computer player only (no human vs human feature). There are 5 levels of difficulties with 1 as the easiest.

Warning: The computer player at level 5 responses very slowly.

This was written a few years ago for educational purposes (i.e to test the author's understanding of the minimax search algorithm with alpha-beta pruning). Back then the author had little knowledge about Java and it's best practices and algorithms in general, so the code isn't that nice and easy to follow and the packages weren't organized well. Also, the final version can no longer be found.

You can see it in action here: https://www.youtube.com/watch?v=I7EGol5DAOE
